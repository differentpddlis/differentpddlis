//a.deleteコマンドはだれでもメッセージを消すことができるので嫌な場合はコードを消すなりしてください
//プレフィックスはa.です。

//npm i @discordjs/opus
//npm i discord.js@12.5.3
//npm i ffmpeg
//npm i dotenv
//npm i express
//npm i ffmpeg-static

//この.jsファイルが入ってるフォルダのパス(\\に注意)
var head = "C:\\Users\\Akasatana\\masterushii\\"
//改良したのでBOTのユーザーIDは入力しなくてOKです


require("dotenv").config();
const { Client, GuildTemplate} = require('discord.js');
const newLocal = require("fs");
const fs = newLocal;
const { clearInterval } = require("timers");
const client = new Client();

client.on('ready', () => {
	console.log(`起動完了`);
  client.user.setActivity('a.help｜音声読み上げが利用できます', {
    type: 'PLAYING'
  });
});

//ヘルプコマンド 
client.on('message', message => {
  if (message.author.bot) return;
  if (message.content === 'a.help') {
    let text = "```a.help = これ\na.avatar <user id or name>= あなたのアイコンを表示します\na.call → 通話に入っている時やると、読み上げBOTが降臨します。\na.dis → 通話に入ってるときにやると、botが退場します。\n\n↓(管理者限定コマンド)↓\na.delete <number>```";
    message.channel.send(text)
    return;
  }
});
//ユーザーアバター
client.on('message', async message => {
  if (message.author.bot) return;
  if(!message.guild)return;
  if (message.content.startsWith("a.avatar")) {

    if(message.content == "a.avatar"){
      message.channel.send(message.author.avatarURL({ format: 'png', dynamic: true, size: 1024 }))
      return;
    }
    try{
      var [name, ...args]= message.content.slice(3).split(' ')
      var Us = await client3.users.fetch(args[0].replace('<@', '').replace('>', '').replace('!',''))
      message.channel.send(Us.avatarURL({ format: 'png', dynamic: true, size: 1024 }))
    }
    catch(err){
      message.channel.send('ユーザーが取得できないです。')
    }

  }
});
//delete
client.on('message', async message => {
  if (message.author.bot) return;
  if(!message.guild)return;
  if (message.member.roles.cache.has('838030295511859250')) {
  if (message.content.startsWith("a.delete")) {
    var [name,...args] = message.content.slice(3).split(' ')
    if(isNaN(args) == true){
      return;
    }
    if(args > 200){
      return;
    }
    const messages = await message.channel.messages.fetch({ limit: args });
    message.channel.bulkDelete(messages);
    let emb = {
      embed: {
      description: 'メッセージを'+args+'個削除しました。' ,
      color: 0xff0000,
      }  
    };
    const reply = await message.channel.send(emb)
    reply.delete({ timeout: 5000 })
  }
  }
});
//vc
client.on('message', async message => {
  if (message.author.bot) return;
  if (message.content == 'a.call'){
    if(message.member.voice.channel == undefined||message.member.voice.channel == null){
      message.channel.send("あなたがボイスチャンネルに参加してないから私が入る意味ないですよね？")
    }else{
      message.member.voice.channel.join().then( conn => {
        let emb = {
          embed: {
            description: 'テキストがかぶった場合早かったやつを読みます。一度に読み上げできる最大文字数は40です。URLなどが含まれる文は読みません。\n対応していない記号が読まれた場合30秒間話せなくなります。',
            color: 0x7b68ee,
          }
        };
        message.channel.send("",emb)
      })
      var log = function(){
        if(message.guild.me.voice.channel == null||message.guild.me.voice.channel == undefined){
          clearInterval(timer)
          return;
        }
        if(message.guild.me.voice.channel.members.size == 1){
          let emb2 = {
            embed: {
              description: 'じゃあね',
              color: 0x7b68ee,
            }
          };
          message.channel.send("",emb2)
          message.guild.me.voice.channel.leave() 
          clearInterval(timer)
        }
      };
      var timer = setInterval(log, 20000);
    }
  }
});
var enable
//vc
client.on('message', async message => {
  if (message.author.bot) return;
  if(message.member.voice.channel == undefined||message.member.voice.channel == null){}else{
    if(message.member.voice.channel == message.guild.me.voice.channel){
      if(enable == false){
        return;
      }
      enable = false

      if(message.content == 'a.call'){
        enable = true
        return;
      }
      if(message.content == 'a.dis'){
        enable = true
        let emb = {
          embed: {
            description: 'じゃあね',
            color: 0x7b68ee,
          }
        };
        message.channel.send("",emb)
        message.member.voice.channel.join().then( ()=> {
          message.member.voice.channel.leave()
        })
        return;
      }
      //個人メンション処理
      if(message.mentions.users.size > 0){
        var id = message.mentions.users.map(user => user.id)
        var name = message.mentions.users.map(user => user.username)
        var str = message.content
        if(message.content.match(/<@!+\d{18}>/)){
          for (let i = 0; i < message.mentions.users.size; i++) {
            str = str.split('<@!' + id[i]+'>').join('@'+name[i]+',')
          }
        }
        if(message.content.match(/<@+\d{18}>/)){
          for (let i = 0; i < message.mentions.users.size; i++) {
            str = str.split('<@' + id[i]+'>').join('@'+name[i]+',')
          }
        }
      }else{
        var str = message.content
      }
      //チャンネルメンション処理
      if(message.mentions.channels.size > 0){
        var id = message.mentions.channels.map(channel => channel.id)
        var name = message.mentions.channels.map(channel => channel.name)
        var str2 = str
        for (let i = 0; i < message.mentions.channels.size; i++) {
          str2 = str2.split('<#' + id[i]+'>').join('@'+name[i]+',')
        }
      }else{
        var str2 = str
      }
      //役職メンション処理
      if(message.mentions.roles.size > 0){
        var id = message.mentions.roles.map(role => role.id)
        var name = message.mentions.roles.map(role => role.name)
        var str3 = str2
        for (let i = 0; i < message.mentions.roles.size; i++) {
          str3 = str3.split('<@&' + id[i]+'>').join('@'+name[i]+',')
        }
      }else{
        var str3 = str2
      }
      var RPD = str3.split(/:+\d{18}>/).join('').split('|').join('').split('_').join('').split('*').join('').split('`').join('').split('>').join('').split('~').join('').split(';').join('').split(':').join('').split('&').join('').split('-').join('').split('\\').join('').split('/').join('').split(':').join('').split('<').join('').split('$').join('').split(' ').join('').split('　').join('').split('\n').join('')
      if(RPD.length > 40||message.content.match(/http/)){
        message.react('👻');
        enable = true
        return;
      }
      require('child_process').exec('start /min よみあげ\\SofTalk.exe /T:0 /V:70 /R:'+head+'読み上げ出力\\'+message.guild.id+'.wav /W:'+RPD)
      var count = 0
      var log = function(){
        count++
        if(count > 30){
          count = 0
          fs.unlinkSync('./読み上げ出力/'+message.guild.id+'.wav');
          clearInterval(timer);
        }
        if(fs.existsSync('./読み上げ出力/'+message.guild.id+'.wav') == true){
          clearInterval(timer);
          message.member.voice.channel.join().then( conn => {
            const dispatcher = conn.play("./読み上げ出力/"+message.guild.id+".wav")
            dispatcher.on("finish", () => {
              enable = true
              fs.unlinkSync('./読み上げ出力/'+message.guild.id+'.wav');
            })
          })
        }
      };
      var timer = setInterval(log, 500);
    }
  }
});

client.login(process.env.DISCORD_BOT_TOKEN);